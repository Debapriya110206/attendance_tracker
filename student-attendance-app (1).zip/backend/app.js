const express = require('express');
const app = express();
const studentRoutes = require('./routes/students');
const attendanceRoutes = require('./routes/attendance');
const mongoose = require('mongoose');
const cors = require('cors');

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/attendance', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

app.use('/students', studentRoutes);
app.use('/attendance', attendanceRoutes);

app.listen(3001, () => {
  console.log('Server is running on port 3001');
});
