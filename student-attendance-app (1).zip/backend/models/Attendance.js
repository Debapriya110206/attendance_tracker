const mongoose = require('mongoose');

const AttendanceSchema = new mongoose.Schema({
  rollNumber: String,
  date: String,
  subject: String,
  present: Boolean
});

module.exports = mongoose.model('Attendance', AttendanceSchema);
