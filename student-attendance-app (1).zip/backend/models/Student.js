const mongoose = require('mongoose');

const StudentSchema = new mongoose.Schema({
  rollNumber: String,
  password: String
});

module.exports = mongoose.model('Student', StudentSchema);
