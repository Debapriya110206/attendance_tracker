const express = require('express');
const router = express.Router();
const Attendance = require('../models/Attendance');

router.post('/mark', async (req, res) => {
  const record = new Attendance(req.body);
  await record.save();
  res.send('Attendance marked');
});

router.get('/:roll', async (req, res) => {
  const records = await Attendance.find({ rollNumber: req.params.roll });
  res.json(records);
});

module.exports = router;
