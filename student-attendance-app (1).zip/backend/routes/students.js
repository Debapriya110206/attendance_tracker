const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

// Dummy auth for simplicity
router.post('/login', async (req, res) => {
  const { rollNumber, password } = req.body;
  const student = await Student.findOne({ rollNumber });
  if (!student || student.password !== password) {
    return res.status(401).send('Invalid credentials');
  }
  res.json({ message: 'Login successful', rollNumber });
});

module.exports = router;
