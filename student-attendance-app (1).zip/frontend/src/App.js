import React from 'react';
import './App.css';

function App() {
  return (
    <div>
      <h1>Student Attendance Dashboard</h1>
    </div>
  );
}

export default App;
